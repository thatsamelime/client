# Shadow Client (starter source)

Minecraft Java 1.21.4 / Fabric client-side starter project.

## Build online
The GitHub Actions workflow in `.github/workflows/build.yml` runs on pushes to `main` and can also be started manually from the Actions tab. If compilation succeeds, download the `shadow-client-jar` artifact from the workflow run.

## Important limitations
This source starter has not been compiled or tested. The Freecam implementation is a placeholder and does not provide functional detached-camera movement. Fix compile errors and implement/test features before distributing or installing the JAR. Check server rules before using ESP or camera utilities in multiplayer.
