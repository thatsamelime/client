package com.shadowclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class ShadowScreen extends Screen {
    public ShadowScreen() {
        super(Text.literal("Shadow Client"));
    }

    @Override
    protected void init() {
        int x = this.width / 2 - 100;
        int y = this.height / 2 - 67;

        this.addDrawableChild(ButtonWidget.builder(status("Coordinates HUD", ShadowClient.showCoordinates),
                button -> {
                    ShadowClient.showCoordinates = !ShadowClient.showCoordinates;
                    button.setMessage(status("Coordinates HUD", ShadowClient.showCoordinates));
                }).dimensions(x, y, 200, 20).build());

        this.addDrawableChild(ButtonWidget.builder(status("FPS HUD", ShadowClient.showFps),
                button -> {
                    ShadowClient.showFps = !ShadowClient.showFps;
                    button.setMessage(status("FPS HUD", ShadowClient.showFps));
                }).dimensions(x, y + 24, 200, 20).build());

        this.addDrawableChild(ButtonWidget.builder(status("Storage ESP", ShadowClient.storageEsp),
                button -> {
                    ShadowClient.storageEsp = !ShadowClient.storageEsp;
                    button.setMessage(status("Storage ESP", ShadowClient.storageEsp));
                }).dimensions(x, y + 48, 200, 20).build());

        this.addDrawableChild(ButtonWidget.builder(status("Freecam", ShadowClient.freecamEnabled),
                button -> {
                    FreecamController.setEnabled(!ShadowClient.freecamEnabled);
                    button.setMessage(status("Freecam", ShadowClient.freecamEnabled));
                }).dimensions(x, y + 72, 200, 20).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Done"),
                button -> this.close()).dimensions(x, y + 102, 200, 20).build());
    }

    private static Text status(String name, boolean enabled) {
        return Text.literal(name + ": " + (enabled ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("SHADOW CLIENT"), this.width / 2, this.height / 2 - 95, 0xAA55FF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
