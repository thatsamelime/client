package com.shadowclient;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.Set;

public final class StorageEsp {
    private static final Set<Block> STORAGE_BLOCKS = Set.of(
            Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.BARREL, Blocks.ENDER_CHEST,
            Blocks.SHULKER_BOX, Blocks.WHITE_SHULKER_BOX, Blocks.ORANGE_SHULKER_BOX,
            Blocks.MAGENTA_SHULKER_BOX, Blocks.LIGHT_BLUE_SHULKER_BOX, Blocks.YELLOW_SHULKER_BOX,
            Blocks.LIME_SHULKER_BOX, Blocks.PINK_SHULKER_BOX, Blocks.GRAY_SHULKER_BOX,
            Blocks.LIGHT_GRAY_SHULKER_BOX, Blocks.CYAN_SHULKER_BOX, Blocks.PURPLE_SHULKER_BOX,
            Blocks.BLUE_SHULKER_BOX, Blocks.BROWN_SHULKER_BOX, Blocks.GREEN_SHULKER_BOX,
            Blocks.RED_SHULKER_BOX, Blocks.BLACK_SHULKER_BOX, Blocks.DECORATED_POT
    );

    private StorageEsp() {}

    public static void register() {
        WorldRenderEvents.LAST.register(context -> {
            if (!ShadowClient.storageEsp) return;

            MinecraftClient client = MinecraftClient.getInstance();
            World world = client.world;
            if (world == null || client.player == null) return;

            var matrices = context.matrixStack();
            if (matrices == null || context.consumers() == null) return;
            Vec3d camera = context.camera().getPos();
            int radius = 24;
            BlockPos center = client.player.getBlockPos();
            VertexConsumer lines = context.consumers().getBuffer(RenderLayer.getLines());

            matrices.push();
            matrices.translate(-camera.x, -camera.y, -camera.z);
            for (BlockPos pos : BlockPos.iterate(center.add(-radius, -radius, -radius),
                                                   center.add(radius, radius, radius))) {
                BlockState state = world.getBlockState(pos);
                if (!STORAGE_BLOCKS.contains(state.getBlock())) continue;
                Box box = new Box(pos).expand(0.002);
                net.minecraft.client.render.WorldRenderer.drawBox(
                        matrices, lines, box, 0.75f, 0.25f, 1.0f, 0.95f);
            }
            matrices.pop();
        });
    }
}
