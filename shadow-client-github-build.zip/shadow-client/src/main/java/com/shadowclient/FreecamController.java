package com.shadowclient;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.Vector3d;
import net.minecraft.util.math.Vec3d;

/**
 * Freecam controller shell.
 *
 * Important: Minecraft 1.21.4 camera detachment is version-sensitive. This class is deliberately
 * a safe starter placeholder rather than using brittle reflection or moving the real player.
 * It provides a toggle state and HUD/menu integration; full detached-camera rendering should be
 * added with a version-matched mixin targeting Camera.update and the camera entity accessor.
 */
public final class FreecamController {
    private FreecamController() {}

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!ShadowClient.freecamEnabled) return;
            // No player movement packets are sent and the real player is not moved.
            // A version-matched Camera mixin is needed for actual camera detachment.
        });
    }

    public static void setEnabled(boolean enabled) {
        ShadowClient.freecamEnabled = enabled;
        // Reset to normal camera state when disabled. Actual detachment requires the mixin noted above.
        if (!enabled) {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client != null && client.player != null) {
                client.setCameraEntity(client.player);
            }
        }
    }
}
