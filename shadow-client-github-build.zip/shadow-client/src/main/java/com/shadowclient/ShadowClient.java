package com.shadowclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class ShadowClient implements ClientModInitializer {
    public static boolean showCoordinates = true;
    public static boolean showFps = true;
    public static boolean storageEsp = false;
    public static boolean freecamEnabled = false;

    private KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.shadow-client.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.shadow-client"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                client.setScreen(new ShadowScreen());
            }
        });

        StorageEsp.register();
        FreecamController.register();

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            var client = net.minecraft.client.MinecraftClient.getInstance();
            if (client.player == null || client.options.hudHidden) return;

            int y = 8;
            if (showCoordinates) {
                String coords = String.format("XYZ: %.1f / %.1f / %.1f",
                        client.player.getX(), client.player.getY(), client.player.getZ());
                drawContext.drawTextWithShadow(client.textRenderer, coords, 8, y, 0xFFFFFF);
                y += 12;
            }
            if (showFps) {
                drawContext.drawTextWithShadow(client.textRenderer,
                        "FPS: " + client.getCurrentFps(), 8, y, 0x55FFFF);
            }
            if (freecamEnabled) {
                drawContext.drawTextWithShadow(client.textRenderer,
                        "FREECAM", 8, y + 12, 0xAA55FF);
            }
        });
    }
}
